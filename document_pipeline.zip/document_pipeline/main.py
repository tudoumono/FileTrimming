"""
main.py - パイプライン実行エントリポイント

使用方法:
    # 全ステップ実行
    python main.py

    # Step 3 から再開（skip モード: 処理済みファイルをスキップ）
    python main.py --start-step 3

    # Step 3 から再開（overwrite モード: 全て再処理）
    python main.py --start-step 3 --mode overwrite

    # Step 2 だけ実行
    python main.py --start-step 2 --end-step 2

    # ドライラン（設定確認のみ）
    python main.py --dry-run
"""

import argparse
import logging
import sys
from pathlib import Path

# プロジェクトルートを sys.path に追加
sys.path.insert(0, str(Path(__file__).parent))

from config import load_config
from pipeline import Pipeline


def setup_logging(level: str):
    log_format = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format=log_format,
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="ドキュメント処理パイプライン",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
例:
  python main.py                                # 全ステップ実行
  python main.py --start-step 3                 # Step 3 から再開
  python main.py --start-step 2 --end-step 2    # Step 2 のみ実行
  python main.py --mode overwrite               # 全て上書き再処理
  python main.py --dry-run                      # 設定確認のみ
        """,
    )
    parser.add_argument("--start-step", type=int, default=None,
                        help="開始ステップ番号 (1-6)")
    parser.add_argument("--end-step", type=int, default=None,
                        help="終了ステップ番号 (1-6)")
    parser.add_argument("--mode", choices=["skip", "overwrite"], default=None,
                        help="中間ファイルの扱い")
    parser.add_argument("--dry-run", action="store_true",
                        help="設定を表示して終了")
    parser.add_argument("--log-level",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        default=None, help="ログレベル上書き")
    return parser.parse_args()


def main():
    args = parse_args()
    config = load_config()

    # CLI 引数で設定を上書き
    if args.mode or args.start_step:
        from dataclasses import replace
        exec_updates = {}
        if args.mode:
            exec_updates["file_conflict_mode"] = args.mode
        if args.start_step:
            exec_updates["start_step"] = args.start_step
        if exec_updates:
            config = replace(config, execution=replace(config.execution, **exec_updates))

    log_level = args.log_level or config.execution.log_level
    setup_logging(log_level)
    logger = logging.getLogger(__name__)

    if args.dry_run:
        logger.info("=== ドライラン（設定確認） ===")
        logger.info("入力: %s (存在: %s)", config.paths.input_dir, config.paths.input_dir.exists())
        logger.info("作業: %s", config.paths.work_dir)
        logger.info("出力: %s", config.paths.output_dir)
        llm_model = config.llm.openai_model if config.llm.provider == "openai" else config.llm.ollama_model
        logger.info("LLM: %s (%s)", config.llm.provider, llm_model)
        logger.info("トークン上限: %d", config.processing.token_limit)
        logger.info("競合モード: %s", config.execution.file_conflict_mode)
        logger.info("開始ステップ: %d", args.start_step or config.execution.start_step)
        return

    pipeline = Pipeline(config)
    try:
        pipeline.run(start_step=args.start_step, end_step=args.end_step)
    except KeyboardInterrupt:
        logger.warning("ユーザーによる中断")
        sys.exit(130)
    except Exception as e:
        logger.error("パイプライン失敗: %s", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
